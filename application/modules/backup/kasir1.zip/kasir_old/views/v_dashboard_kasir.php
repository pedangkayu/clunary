
	<iframe name="checker" src="<?php echo site_url().'/kasir/c_transaksi/cek/'.$status; ?>" frameborder="0" width="100%" height="580px" style="padding:0; overflow:hidden;">			
		
	</iframe>
	